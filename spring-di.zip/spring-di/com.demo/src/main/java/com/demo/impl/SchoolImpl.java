package com.demo.impl;

public class SchoolImpl implements School {
 
    @Override
    public void info() {
        System.out.println("ABC International School.");
    }
}