package com.demo.impl;

public interface School {

	void info();
}
